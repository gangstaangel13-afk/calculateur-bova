CALCULATEUR BOVA - PROJET ANDROID AVEC COMPILATION EN LIGNE

Le dossier app/src/main/assets contient le calculateur V14.
Le projet est configuré pour produire un APK Android de test (debug).

TU N'AS PAS BESOIN D'UN ORDINATEUR : COMPILATION DEPUIS TON TÉLÉPHONE
La compilation se fait sur les serveurs GitHub Actions. Il faut un compte GitHub.

1. Depuis Chrome sur ton téléphone, ouvre https://github.com et crée/connecte-toi à ton compte.
2. Crée un nouveau dépôt (repository), par exemple "calculateur-bova".
3. Décompresse ce ZIP si ton téléphone le permet, puis téléverse le contenu du dossier
   CalculateurBova dans le dépôt GitHub. Il faut bien conserver le dossier caché
   .github/workflows avec le fichier build-apk.yml.
4. Dans le dépôt GitHub, ouvre l'onglet Actions.
5. Sélectionne "Construire APK Android", puis "Run workflow".
6. Attends la fin du travail (les voyants doivent être verts).
7. Ouvre l'exécution terminée et télécharge l'artefact "Calculateur-Bova-APK".
   Il contient app-debug.apk.
8. Télécharge app-debug.apk sur ton téléphone et ouvre-le pour l'installer.
   Android peut demander d'autoriser l'installation depuis Chrome ou Fichiers.

GOOGLE MAPS
- Google Maps nécessite une connexion Internet et ta propre clé API.
- Ne publie pas ta clé dans le dépôt GitHub.
- Colle-la uniquement dans le champ prévu dans l'application.
- Active Routes API et Maps JavaScript API, la facturation Google Cloud et limite
  la clé aux API nécessaires.
- Vérifie les itinéraires : Google calcule une route automobile ordinaire, pas une
  route garantie compatible avec la hauteur, le poids ou les restrictions autocar.

IMPORTANT
Le ZIP est le projet source et le processus de compilation à lancer sur GitHub.
Ce n'est pas encore le fichier APK compilé. Le fichier APK sera produit par GitHub
Actions après lancement du workflow.
